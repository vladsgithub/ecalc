﻿<?php
/**
 * Главная страница (index.php)
 * @package WordPress
 * @subpackage ecalc-template
 */
get_header(); // подключаем header.php ?>

The site is in progress

<?php get_footer(); // подключаем footer.php ?>
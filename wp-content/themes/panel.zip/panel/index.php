<?php
/**
 * Главная страница (index.php)
 * @package WordPress
 * @subpackage ecalc-template
 */
get_header(); // подключаем header.php ?>





<!-- BEGIN: SINGLE PAGE/////////////////////////////////////// -->

<?php
	include('page.html');
//	include('prototype.html');
?>

<!-- END: SINGLE PAGE/////////////////////////////////////// -->





<?php get_footer(); // подключаем footer.php ?>
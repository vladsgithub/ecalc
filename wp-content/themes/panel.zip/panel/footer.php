<?php
/**
 * Шаблон подвала (footer.php)
 * @package WordPress
 * @subpackage ecalc-template
 */
?>
	<footer>
		Footer
	</footer>
<?php wp_footer(); // необходимо для работы плагинов и функционала  ?>
</body>
</html>